class Singleton(type):
    _instances = {}

    def __call__(cls, *args, **kwargs):
        if cls not in cls._instances:
            cls._instances[cls] = super(Singleton, cls).__call__(*args, **kwargs)
        return cls._instances[cls]


class Values(object, metaclass=Singleton):
    """Static holder for all public Variables like Temperature/Humidity/Time etc."""

    def __init__(self):
        super(Values, self).__init__()
        # load values
        self._valuesDict = {}
        self._subscribers = []

    def getVals(self):
        return self._valuesDict

    def setValue(self, valName, val, visibility=True, typeName=""):
        if valName in self._valuesDict.keys():
            self._valuesDict[valName].value = val
        else:
            self._valuesDict[valName] = Value(val, visibility, typeName)

    def getValue(self, valName):
        if valName in self._valuesDict.keys():
            return self._valuesDict[valName]
        else:
            return None


class Value(object):
    def __init__(self, value, visible=True, typeName=""):
        super(Value, self).__init__()
        self._value = value
        self._visible = visible
        self._typeName = typeName
        self._subscribers = []

    @property
    def value(self):
        return self._value

    @value.setter
    def value(self, value):
        self._value = value
        self.notify()

    @property
    def visible(self):
        return self._visible

    @property
    def typeName(self):
        return self._typeName

    @typeName.setter
    def typeName(self, value):
        self._typeName = value

    def subscribe(self, scenario):
        if scenario not in self._subscribers:
            self._subscribers.append(scenario)

    def notify(self):
        print("value with number of subscribers" + str(len(self._subscribers)))
        for subscriber in self._subscribers:
            subscriber.performScenario()
