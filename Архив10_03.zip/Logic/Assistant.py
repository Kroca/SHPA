from Logic.MQTTManager import MQTTManager
from DAO.Storage import Storage
from Util.HistoryLogger import HistoryLogger

mqttManager = MQTTManager()
logger = HistoryLogger()
mqttManager.start()
storage = Storage()


def sendMQTTMessage(topic, message):
    mqttManager.getClient().publish(topic, message)
