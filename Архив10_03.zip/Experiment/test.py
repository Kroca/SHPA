import Logic.Condition as condition
